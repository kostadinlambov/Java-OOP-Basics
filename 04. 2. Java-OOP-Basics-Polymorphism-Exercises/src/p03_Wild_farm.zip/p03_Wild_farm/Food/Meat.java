package p03_Wild_farm.Food;

public class Meat extends Food {
    public Meat(int quantity) {
        super(quantity);
    }
}
