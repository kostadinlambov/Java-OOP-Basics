package p02_Vehicles_Extension;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


        String[] carTokens = reader.readLine().split("\\s+");
        double fuelQuantityCar = Double.parseDouble(carTokens[1]);
        double fuelConsumptionCar = Double.parseDouble(carTokens[2]);
        double tankCapacityCar = Double.parseDouble(carTokens[3]);
        Vehicle car  = new Car(fuelQuantityCar, fuelConsumptionCar, tankCapacityCar);

        String[] truckTokens = reader.readLine().split("\\s+");
        double fuelQuantityTruck = Double.parseDouble(truckTokens[1]);
        double fuelConsumptionTruck = Double.parseDouble(truckTokens[2]);
        double tankCapacityTruck = Double.parseDouble(truckTokens[3]);
        Vehicle truck  = new Truck(fuelQuantityTruck, fuelConsumptionTruck, tankCapacityTruck);

        String[] busTokens = reader.readLine().split("\\s+");
        double fuelQuantityBus = Double.parseDouble(busTokens[1]);
        double fuelConsumptionBus = Double.parseDouble(busTokens[2]);
        double tankCapacityBus = Double.parseDouble(busTokens[3]);
        Vehicle bus  = new Bus(fuelQuantityBus, fuelConsumptionBus, tankCapacityBus);


        int numbersOfCommands = Integer.parseInt(reader.readLine());

        for (int i = 0; i < numbersOfCommands; i++) {
            String[] tokens = reader.readLine().split("\\s+");

            String command = tokens[0];
            String vehicleType = tokens[1];
            double distanceOrLiters = Double.parseDouble(tokens[2]);
            try {
                switch (command) {
                    case "Drive":
                        if ("Car".equalsIgnoreCase(vehicleType)) {
                            car.drive(distanceOrLiters);
                        } else if("Truck".equalsIgnoreCase(vehicleType)){
                            truck.drive(distanceOrLiters);
                        }else{
                            bus.drive(distanceOrLiters);
                        }
                        break;
                    case "Refuel":
                        if ("Car".equalsIgnoreCase(vehicleType)) {
                            car.refueling(distanceOrLiters);
                        }  else if("Truck".equalsIgnoreCase(vehicleType)){
                            truck.refueling(distanceOrLiters);
                        }else{
                            bus.refueling(distanceOrLiters);
                        }
                        break;
                    case "DriveEmpty":
                        bus.driveEmpty(distanceOrLiters);
                        break;
                }
            }catch (IllegalArgumentException iae){
                System.out.println(iae.getMessage());
            }

        }
        System.out.println(car.toString());
        System.out.println(truck.toString());
        System.out.println(bus.toString());
    }
}
