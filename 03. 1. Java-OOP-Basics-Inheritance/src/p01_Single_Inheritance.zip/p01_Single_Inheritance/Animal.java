package p01_Single_Inheritance;

public class Animal {

    void eat() {
        System.out.println("eating...");
    }
}
