package p01_Single_Inheritance;

public class Dog extends Animal {

    void bark(){
        System.out.println("barking...");
    }
}
