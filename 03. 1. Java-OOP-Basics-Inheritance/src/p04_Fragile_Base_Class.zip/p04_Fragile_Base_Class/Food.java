package p04_Fragile_Base_Class;

public class Food {
}
