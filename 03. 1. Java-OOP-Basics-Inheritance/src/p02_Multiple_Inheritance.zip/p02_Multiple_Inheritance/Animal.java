package p02_Multiple_Inheritance;

public class Animal {

    void eat() {
        System.out.println("eating...");
    }
}
