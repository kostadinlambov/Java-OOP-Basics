package p02_Multiple_Inheritance;

public class Puppy extends Dog{
    void weep(){
        System.out.println("weeping...");
    }
}
