package p02_Multiple_Inheritance;

public class Main {
    public static void main(String[] args) {

        Puppy dog = new Puppy();
        dog.eat();
        dog.bark();
        dog.weep();
    }
}
