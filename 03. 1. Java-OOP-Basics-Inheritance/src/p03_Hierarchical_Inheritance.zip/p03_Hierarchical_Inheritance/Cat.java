package p03_Hierarchical_Inheritance;

public class Cat extends Animal {

    void meow() {
        System.out.println("meowing…");
    }

}
