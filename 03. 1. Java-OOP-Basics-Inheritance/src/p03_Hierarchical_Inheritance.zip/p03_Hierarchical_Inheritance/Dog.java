package p03_Hierarchical_Inheritance;

public class Dog extends Animal {

    void bark(){
        System.out.println("barking...");
    }
}
