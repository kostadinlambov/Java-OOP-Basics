package p03_Hierarchical_Inheritance;

class Animal {

    void eat() {
        System.out.println("eating...");
    }
}
