package exam.entities.colonists.engineers;

public class SoftwareEngineer extends Engineer {

    public SoftwareEngineer(String id, String familyId, int talent, int age) {
        super(id, familyId, talent, age);
    }

//    @Override
//    public int getPotential() {
//        int additionalBonus = 2;
//        //   return super.getPotential() + additionalBonus;
//        return additionalBonus;
//    }

    @Override
    public int getPotential() {
        int classBonus = 5;
        int ageBonus = 0;

        int additionalBonus = this.getTalent() + classBonus + ageBonus;

        //TODO Gets a flat bonus +2, regardless of age or talent?????
      //????  int additionalBonus =   classBonus + ageBonus;

        // return super.getPotential() + additionalBonus;
        return  additionalBonus;
    }
}
