package exam.entities.colonists.medics;

public class GeneralPractitioner extends Medic {

    public GeneralPractitioner(String id, String familyId, int talent, int age, String sign) {
        super(id, familyId, talent, age, sign);
    }


//    @Override
//    public int getPotential() {
//        int classBonus = 2;
//        // int ageBonus = 3;
//        return classBonus;
//    }


    @Override
    public int getPotential() {
        int ageBonus = 0;
        int classBonus = 2;

        if(super.getAge() > 15){
            ageBonus += 1;
        }

        if("caring".equals( super.getSign())){
            classBonus += 1;
        }else if("careless".equals( super.getSign())){
            classBonus -= 2;
        }

        int totalBonus = super.getTalent() + ageBonus + classBonus;
       // return super.getPotential() + totalBonus;
        return totalBonus;
    }
}
