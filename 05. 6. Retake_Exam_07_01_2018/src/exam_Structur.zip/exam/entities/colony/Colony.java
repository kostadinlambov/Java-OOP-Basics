package exam.entities.colony;

import exam.entities.colonists.Colonist;
import exam.entities.families.Family;

import java.util.*;
import java.util.stream.Collectors;

public class Colony {
    private int maxFamilyCount;
    private int maxFamilyCapacity;
    //private List<Family> families;
    private Map<String, Family> families;


    public Colony(int maxFamilyCount, int maxFamilyCapacity) {
        this.maxFamilyCount = maxFamilyCount;
        this.maxFamilyCapacity = maxFamilyCapacity;
       // this.families = new ArrayList<>();
        this.families = new LinkedHashMap<>();
    }


    public List<Colonist> getColonistsByFamilyId(String familyId) {
        // Family family = families.stream().filter(x -> x.getId().equals(familyId)).findFirst().get();
//        for (Family currentFamily : families) {
//            if(currentFamily.getId().equals(familyId)){
//                family = currentFamily;
//            }
//        }

        Family family = families.get(familyId);

        List<Colonist> colonists = family.getColonists().stream()
                .sorted(Comparator.comparing(Colonist::getId))
                .collect(Collectors.toList());

        return Collections.unmodifiableList(colonists);
    }

    public int getMaxFamilyCount() {
        return this.maxFamilyCount;
    }

    public int getMaxFamilyCapacity() {
        return this.maxFamilyCapacity;
    }


//    public List<Family> getFamilies() {
//        return Collections.unmodifiableList(this.families);
//    }
}
