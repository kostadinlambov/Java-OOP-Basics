package exam.utilities;

public class Constants {
    private Constants() {
    }
}
