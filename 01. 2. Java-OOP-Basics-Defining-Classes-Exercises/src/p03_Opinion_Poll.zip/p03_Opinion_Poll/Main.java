package p03_Opinion_Poll;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.TreeMap;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        TreeMap<String, Integer> personsMap = new TreeMap<>();


        int n = Integer.parseInt(reader.readLine());

        for (int i = 0; i < n; i++) {
            Person person = new Person();

            String[] inputLine = reader.readLine().split("\\s+");

            String name = inputLine[0];
            int age = Integer.parseInt(inputLine[1]);


            if(age > 30){
                person.setName(name);
                person.setAge(age);
                personsMap.putIfAbsent(person.getName(), person.getAge());
            }
        }

        personsMap.forEach((key, value) -> System.out.println(key + " - " + value));


    }
}
