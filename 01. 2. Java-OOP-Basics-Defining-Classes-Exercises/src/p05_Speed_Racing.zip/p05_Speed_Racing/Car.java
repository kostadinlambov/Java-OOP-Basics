package p05_Speed_Racing;

class Car {
    private String model;
    private double fuelAmount;
    private double fuelCost;
    private double distanceTraveled;
    
    Car(String model, double fuelAmount, double fuelCost) {
        this.model = model;
        this.fuelAmount = fuelAmount;
        this.fuelCost = fuelCost;
    }

    String getModel() {
        return this.model;
    }

    double getFuelAmount() {
        return this.fuelAmount;
    }

    double getDistanceTraveled() {
        return this.distanceTraveled;
    }

    void calculateCanMoveTheDistance(int distanceToMove) {
        double reachableDistance = fuelAmount / fuelCost;
        if (reachableDistance >= distanceToMove) {
            distanceTraveled += distanceToMove;
            fuelAmount -= distanceToMove * fuelCost;
        } else {
            System.out.println("Insufficient fuel for the drive");
        }
    }
}
