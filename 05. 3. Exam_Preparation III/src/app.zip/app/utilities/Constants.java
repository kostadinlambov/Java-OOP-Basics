package app.utilities;

public class Constants {

    public static final String INPUT_TERMINATING_COMMAND = "Paw Paw Pawah";
    private Constants() {
    }
}
