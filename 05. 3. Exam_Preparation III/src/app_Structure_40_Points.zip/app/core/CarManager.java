package app.core;


import java.util.*;

public class CarManager {

//    private Map<Integer, Car> carsMap;
//    private Map<Integer, Race> racesMap;
//    private Garage garage;
//
//    private Map<Integer, List<Integer>> carsRegisteredToRaceMap;
//    private List<Integer> garageCarsIdList;
//   // List<Integer> carsRegisteredToRaceList = new ArrayList<>();
//
//    public CarManager() {
//        this.carsMap = new LinkedHashMap<>();
//        this.racesMap = new LinkedHashMap<>();
//        this.garage = new Garage();
//        this.carsRegisteredToRaceMap = new LinkedHashMap<>();
//        this.garageCarsIdList = new ArrayList<>();
//    }


//    }
}
