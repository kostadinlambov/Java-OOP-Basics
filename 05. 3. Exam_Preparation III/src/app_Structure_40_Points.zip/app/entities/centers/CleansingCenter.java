package app.entities.centers;

import app.entities.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public class CleansingCenter extends Center {

    public CleansingCenter(String name) {
        super(name);
    }


//    public void cleanse(String cleansingCenterName) {
//        List<Animal> animalsList = this.getAnimalsInTheCenter();
//        // this.setAnimalsInTheCenter(new ArrayList<>());
//        // return animalsList;
//    }
}
