package app.entities.centers;

import app.entities.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public class AdoptionCenter extends Center {


    public AdoptionCenter(String name) {
        super(name);
    }
//
//    public void sendingForCleansing(String adoptionCenterName, String cleansingCenterName) {
////        List<Animal> animalsList = this.getAnimalsInTheCenter();
////        this.setAnimalsInTheCenter(new ArrayList<>());
//        // return animalsList;
//    }
//
//    public List<Animal> adopt(String adoptionCenterName){
//        List<Animal> animalsList = this.getAnimalsInTheCenter();
//        //this.setAnimalsInTheCenter(new ArrayList<>());
//        return animalsList;
//    }
}
