package app.entities.centers;

import app.entities.animals.Animal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Center {
    private String name;
    private List<Animal> animalsInTheCenter;


    protected Center(String name) {
        this.setName(name);
        this.animalsInTheCenter = new ArrayList<>();
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public List<Animal> getAnimalsInTheCenter() {
        return Collections.unmodifiableList(this.animalsInTheCenter);
    }
}
