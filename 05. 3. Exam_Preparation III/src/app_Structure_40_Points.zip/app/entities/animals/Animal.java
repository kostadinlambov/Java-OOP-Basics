package app.entities.animals;

public abstract class Animal {

    private String name;
    private int age;
    private boolean cleansingStatus;

    protected Animal(String name, int age){
        this.setName(name);
        this.setAge(age);
        this.setCleansingStatus();
    }

    private void setCleansingStatus(){
        this.cleansingStatus = false;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public boolean isCleansingStatus() {
        return this.cleansingStatus;
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setAge(int age) {
        this.age = age;
    }
}
