package app.factories;



public final class RaceFactory {

//    private RaceFactory() {
//    }
//
//    public static Race createRace(String type, int length, String route, int prizePool) {
//        switch (type) {
//            case "Casual":
//                return new CasualRace(length, route, prizePool);
//            case "Drag":
//                return new DragRace(length, route, prizePool);
//            case "Drift":
//                return new DriftRace(length, route, prizePool);
//        }
//        return null;
//    }
}
