package app.engines;

import app.core.CarManager;
import app.io.ConsoleInputReader;
import app.io.ConsoleOutputWriter;
import app.utilities.InputParser;

import java.util.List;

public class Engine {
    private ConsoleInputReader inputReader;
    private ConsoleOutputWriter outputWriter;
    private InputParser inputParser;
    private CarManager carManager;

    public Engine(ConsoleInputReader inputReader, ConsoleOutputWriter outputWriter, InputParser inputParser,
                  CarManager carManager) {
        this.inputReader = inputReader;
        this.outputWriter = outputWriter;
        this.inputParser = inputParser;
        this.carManager = carManager;
    }

    public void run() {
        String inputLine;

        while (true) {
            inputLine = this.inputReader.readLine();
            List<String> commandParams = this.inputParser.parseInput(inputLine);

            this.dispatchCommand(commandParams);
            //INPUT_TERMINATING_COMMAND - this is your terminated command
            if (inputLine.equals("Cops Are Here")) {
                break;
            }
        }
    }

    private void dispatchCommand(List<String> commandParams) {
        String command = commandParams.remove(0);

        switch (command) {
            case "register":
                int id = Integer.parseInt(commandParams.get(0));
                String type = commandParams.get(1);
                String brand = commandParams.get(2);
                String model = commandParams.get(3);
                int yearOfProduction = Integer.parseInt(commandParams.get(4));
                int horsepower = Integer.parseInt(commandParams.get(5));
                int acceleration = Integer.parseInt(commandParams.get(6));
                int suspension = Integer.parseInt(commandParams.get(7));
                int durability = Integer.parseInt(commandParams.get(8));

//                this.carManager.register(id, type, brand, model, yearOfProduction, horsepower,
//                        acceleration, suspension, durability);
                break;
            case "check":

                break;
            case "open":

                break;
            case "participate":
                break;
            case "start":
                break;
            case "park":

                break;
            case "unpark":

                break;
            case "tune":

                break;
        }
    }
}
