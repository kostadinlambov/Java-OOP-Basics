package Test;

// Правим класа final, за да не може той да се наследява от
// други класове
public final class GlobalConstants {

    public static final String CONSTANT = "Im a constant";

    // Класа не трябва да може да се инициализира извън класа,
    // затова декларираме САМИ един празен конструктор,
    // който обаче трябва задължитено да е с private модификатор
    private GlobalConstants() {
    }
}
