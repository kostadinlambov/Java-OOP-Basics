package systemSplit.controller;

import systemSplit.factories.HardwareFactory;
import systemSplit.factories.SoftwareFactory;
import systemSplit.models.Software.SoftwareComponent;
import systemSplit.models.hardware.HardwareComponent;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ComponentManager {
    Map<String, HardwareComponent> hardwareComponentMap;

    public ComponentManager() {
        this.hardwareComponentMap = new LinkedHashMap<>();
    }

    public void registerPowerHardware(String name, int capacity, int memory) {
        HardwareComponent hardwareComponent = HardwareFactory.createPowerHardware(name, capacity, memory);
        this.hardwareComponentMap.putIfAbsent(name, hardwareComponent);
    }

    public void registerHeavyHardware(String name, int capacity, int memory) {
        HardwareComponent hardwareComponent = HardwareFactory.createHeavyHardware(name, capacity, memory);
        this.hardwareComponentMap.putIfAbsent(name, hardwareComponent);
    }

    public void registerExpressSoftware(String hardwareComponentName, String name, int capacity, int memory) {

        SoftwareComponent softwareComponent = SoftwareFactory.createExpressSoftware(name, capacity, memory);
        if (hardwareComponentMap.containsKey(hardwareComponentName)) {
            hardwareComponentMap.get(hardwareComponentName).registerSoftwareComponent(softwareComponent);
        }
    }

    public void registerLightSoftware(String hardwareComponentName, String name, int capacity, int memory) {

        SoftwareComponent softwareComponent = SoftwareFactory.createLightSoftware(name, capacity, memory);
        if (hardwareComponentMap.containsKey(hardwareComponentName)) {
            hardwareComponentMap.get(hardwareComponentName).registerSoftwareComponent(softwareComponent);
        }
    }

    public void releaseSoftwareComponent(String hardwareComponentName, String softwareComponentName) {
        if (hardwareComponentMap.containsKey(hardwareComponentName)) {
            hardwareComponentMap.get(hardwareComponentName).releaseSoftwareComponent(softwareComponentName);
        }
    }

    public void analyze() {

        int softCompCount = 0;
        int totalMemory = 0;
        int totalOperationalMemoryInUse = 0;
        int totalCapacityTaken = 0;
        int maximumCapacity = 0;
        for (HardwareComponent hardwareComponent : hardwareComponentMap.values()) {
            softCompCount += hardwareComponent.getRegSoftCompCount();
            totalMemory += hardwareComponent.getMaximumMemory();
            totalOperationalMemoryInUse += hardwareComponent.getTotalMemoryConsumption();
            totalCapacityTaken += hardwareComponent.getTotalCapacityConsumption();
            maximumCapacity += hardwareComponent.getMaximumCapacity();
        }
        //StringBuilder sb = new StringBuilder();

        System.out.println("System Analysis");
        System.out.printf("Hardware Components: %d%n", hardwareComponentMap.size());
        System.out.printf("Software Components: %d%n", softCompCount);
        System.out.printf("Total Operational Memory: %d / %d%n", totalOperationalMemoryInUse, totalMemory);
        System.out.printf("Total Capacity Taken: %d / %d%n", totalCapacityTaken, maximumCapacity);
    }

    public void split() {
        Map<String, HardwareComponent> sortedMap = hardwareComponentMap.entrySet().stream()
                .sorted((a, b) ->  b.getValue().getType().compareTo(a.getValue().getType()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));

        for (Map.Entry<String, HardwareComponent> hardwareComponent : sortedMap.entrySet()) {
            System.out.printf("Hardware Component – %s%n", hardwareComponent.getKey());
            System.out.printf("Express Software Components: %d%n", hardwareComponent.getValue().getExpressSoftwareComponentsCount());
            System.out.printf("Light Software Components: %s%n", hardwareComponent.getValue().getLightSoftwareComponentsCount());
            System.out.printf("Memory Usage: %d / %d%n",
                    hardwareComponent.getValue().getTotalMemoryConsumption(), hardwareComponent.getValue().getMaximumMemory());
            System.out.printf("Capacity Usage: %d / %d%n",
                    hardwareComponent.getValue().getTotalCapacityConsumption(), hardwareComponent.getValue().getMaximumCapacity());
            System.out.printf("Type: %s%n", hardwareComponent.getValue().getType());
            System.out.printf("Software Components: %s%n", hardwareComponent.getValue().getListOfSoftwareComponents());
        }
    }
}



