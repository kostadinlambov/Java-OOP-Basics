package p06_Animals;

public class Kitten extends Cat{
    public Kitten(String name, int age, String gender) {
        super(name, age, gender);
    }


    @Override
    protected void setGender(String gender) {
        if (gender == null ||  !("Female".equals(gender))) {
            throw new IllegalArgumentException("Invalid input!");
        }
        super.setGender(gender);
    }

    @Override
    public String produceSound() {
        return "Miau";

    }
}
