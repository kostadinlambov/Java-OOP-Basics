package p06_Animals;

public final class ErrorMessageConstants {

    public static final String INVALID_INPUT_MESSAGE = "Invalid input!";

    private ErrorMessageConstants() {
    }
}
