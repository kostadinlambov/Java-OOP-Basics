package p06_Animals;

public interface SoundProducible {
    String produceSound();
}
